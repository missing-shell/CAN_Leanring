﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using ZLGCAN;

namespace ZLGCANDemo
{
    public partial class ZCLOUD : Form
    {
        private bool connected_ = false;
        private List<uint> deviceIndices_ = new List<uint>();
        private List<int> deviceStatus_ = new List<int>();
        private bool online_ = false;

        public ZCLOUD()
        {
            InitializeComponent();
        }

        public uint deviceIndex()
        {
            if (deviceList.Items.Count > 0)
            {
                return deviceIndices_[deviceList.SelectedIndices[0]];
            }
            else
            {
                return 0;
            }
        }

        private void ZCLOUD_Load(object sender, EventArgs e)
        {
            username.Text = "123";
            password.Text = "123";

            deviceList.Columns.Add("ID", deviceList.Width - 60, HorizontalAlignment.Left);
            deviceList.Columns.Add("状态", 50, HorizontalAlignment.Center);
            deviceList.View = System.Windows.Forms.View.Details;
            deviceList.FullRowSelect = true;

            notifyControl();
        }

        private void notifyControl()
        {
            httpAddr.Enabled = !connected_;
            httpPort.Enabled = !connected_;
            mqttAddr.Enabled = !connected_;
            mqttPort.Enabled = !connected_;
            username.Enabled = !connected_;
            password.Enabled = !connected_;
            connect.Enabled = !connected_;
            disconnect.Enabled = connected_;
            deviceList.Enabled = connected_;
            confirm.Enabled = online_;
        }

        private void connect_Click(object sender, EventArgs e)
        {
            
        }

        private void disconnect_Click(object sender, EventArgs e)
        {
          
        }

        private void deviceList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (deviceList.SelectedIndices.Count == 0)
            {
                online_ = false;
            }
            else
            {
                int index = deviceList.SelectedIndices[0];
                online_ = deviceIndices_[index] == 0;
            }
            notifyControl();
        }

        private void confirm_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
