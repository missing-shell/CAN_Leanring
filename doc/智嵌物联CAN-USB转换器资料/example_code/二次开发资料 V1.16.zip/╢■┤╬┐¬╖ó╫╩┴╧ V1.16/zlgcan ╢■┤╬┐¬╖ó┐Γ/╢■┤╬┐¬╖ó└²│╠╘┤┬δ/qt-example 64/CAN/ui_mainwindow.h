/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_3;
    QComboBox *workStatusCombo;
    QLabel *label_4;
    QComboBox *canFDStandardCombo;
    QCheckBox *resistanceCheckBox;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QComboBox *ABIT1Combo;
    QLabel *label_6;
    QComboBox *ABIT2Combo;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout;
    QCheckBox *CustomBaudrateCheckBox;
    QLineEdit *CustomBaudrateEdit;
    QLabel *label_7;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_8;
    QComboBox *filterModeCombo;
    QLabel *label_9;
    QLineEdit *StartIDEdit;
    QLabel *label_10;
    QLineEdit *endIDEdit;
    QGroupBox *groupBox_2;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_11;
    QLineEdit *sendIDEdit;
    QLabel *label_12;
    QComboBox *frameTypeCombo;
    QLabel *label_13;
    QComboBox *protocolCombo;
    QCheckBox *CANFDaccCheck;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_14;
    QLineEdit *sendDataEdit;
    QWidget *layoutWidget6;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_15;
    QComboBox *sendPathCombo;
    QPushButton *sendBtn;
    QGroupBox *groupBox_3;
    QPushButton *cleanListBtn;
    QTableWidget *tableWidget;
    QCheckBox *checkBox_4;
    QWidget *layoutWidget7;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label;
    QComboBox *deviceTypeCombo;
    QLabel *label_2;
    QComboBox *deviceIndexCombo;
    QWidget *layoutWidget8;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *openDeviceBtn;
    QPushButton *initCANBtn;
    QPushButton *StartCANBtn;
    QPushButton *reSetCANBtn;
    QPushButton *closeDeviceBtn;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1000, 810);
        MainWindow->setMinimumSize(QSize(1000, 810));
        MainWindow->setMaximumSize(QSize(1000, 810));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(0, 70, 691, 181));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 20, 581, 23));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_4->addWidget(label_3);

        workStatusCombo = new QComboBox(layoutWidget);
        workStatusCombo->addItem(QString());
        workStatusCombo->addItem(QString());
        workStatusCombo->setObjectName(QString::fromUtf8("workStatusCombo"));

        horizontalLayout_4->addWidget(workStatusCombo);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        canFDStandardCombo = new QComboBox(layoutWidget);
        canFDStandardCombo->addItem(QString());
        canFDStandardCombo->addItem(QString());
        canFDStandardCombo->setObjectName(QString::fromUtf8("canFDStandardCombo"));

        horizontalLayout_4->addWidget(canFDStandardCombo);

        resistanceCheckBox = new QCheckBox(layoutWidget);
        resistanceCheckBox->setObjectName(QString::fromUtf8("resistanceCheckBox"));

        horizontalLayout_4->addWidget(resistanceCheckBox);

        layoutWidget1 = new QWidget(groupBox);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 60, 441, 23));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_3->addWidget(label_5);

        ABIT1Combo = new QComboBox(layoutWidget1);
        ABIT1Combo->addItem(QString());
        ABIT1Combo->addItem(QString());
        ABIT1Combo->addItem(QString());
        ABIT1Combo->addItem(QString());
        ABIT1Combo->addItem(QString());
        ABIT1Combo->addItem(QString());
        ABIT1Combo->addItem(QString());
        ABIT1Combo->setObjectName(QString::fromUtf8("ABIT1Combo"));

        horizontalLayout_3->addWidget(ABIT1Combo);

        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_3->addWidget(label_6);

        ABIT2Combo = new QComboBox(layoutWidget1);
        ABIT2Combo->addItem(QString());
        ABIT2Combo->addItem(QString());
        ABIT2Combo->addItem(QString());
        ABIT2Combo->addItem(QString());
        ABIT2Combo->setObjectName(QString::fromUtf8("ABIT2Combo"));

        horizontalLayout_3->addWidget(ABIT2Combo);

        layoutWidget2 = new QWidget(groupBox);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(10, 100, 671, 23));
        horizontalLayout = new QHBoxLayout(layoutWidget2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        CustomBaudrateCheckBox = new QCheckBox(layoutWidget2);
        CustomBaudrateCheckBox->setObjectName(QString::fromUtf8("CustomBaudrateCheckBox"));

        horizontalLayout->addWidget(CustomBaudrateCheckBox);

        CustomBaudrateEdit = new QLineEdit(layoutWidget2);
        CustomBaudrateEdit->setObjectName(QString::fromUtf8("CustomBaudrateEdit"));

        horizontalLayout->addWidget(CustomBaudrateEdit);

        label_7 = new QLabel(layoutWidget2);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout->addWidget(label_7);

        layoutWidget3 = new QWidget(groupBox);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(10, 140, 671, 23));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(layoutWidget3);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_2->addWidget(label_8);

        filterModeCombo = new QComboBox(layoutWidget3);
        filterModeCombo->addItem(QString());
        filterModeCombo->addItem(QString());
        filterModeCombo->addItem(QString());
        filterModeCombo->setObjectName(QString::fromUtf8("filterModeCombo"));

        horizontalLayout_2->addWidget(filterModeCombo);

        label_9 = new QLabel(layoutWidget3);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_2->addWidget(label_9);

        StartIDEdit = new QLineEdit(layoutWidget3);
        StartIDEdit->setObjectName(QString::fromUtf8("StartIDEdit"));

        horizontalLayout_2->addWidget(StartIDEdit);

        label_10 = new QLabel(layoutWidget3);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_2->addWidget(label_10);

        endIDEdit = new QLineEdit(layoutWidget3);
        endIDEdit->setObjectName(QString::fromUtf8("endIDEdit"));

        horizontalLayout_2->addWidget(endIDEdit);

        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(0, 300, 691, 121));
        layoutWidget4 = new QWidget(groupBox_2);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(10, 20, 661, 23));
        horizontalLayout_7 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_11 = new QLabel(layoutWidget4);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        horizontalLayout_7->addWidget(label_11);

        sendIDEdit = new QLineEdit(layoutWidget4);
        sendIDEdit->setObjectName(QString::fromUtf8("sendIDEdit"));

        horizontalLayout_7->addWidget(sendIDEdit);

        label_12 = new QLabel(layoutWidget4);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        horizontalLayout_7->addWidget(label_12);

        frameTypeCombo = new QComboBox(layoutWidget4);
        frameTypeCombo->addItem(QString());
        frameTypeCombo->addItem(QString());
        frameTypeCombo->setObjectName(QString::fromUtf8("frameTypeCombo"));

        horizontalLayout_7->addWidget(frameTypeCombo);

        label_13 = new QLabel(layoutWidget4);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        horizontalLayout_7->addWidget(label_13);

        protocolCombo = new QComboBox(layoutWidget4);
        protocolCombo->addItem(QString());
        protocolCombo->addItem(QString());
        protocolCombo->setObjectName(QString::fromUtf8("protocolCombo"));

        horizontalLayout_7->addWidget(protocolCombo);

        CANFDaccCheck = new QCheckBox(layoutWidget4);
        CANFDaccCheck->setObjectName(QString::fromUtf8("CANFDaccCheck"));

        horizontalLayout_7->addWidget(CANFDaccCheck);

        layoutWidget5 = new QWidget(groupBox_2);
        layoutWidget5->setObjectName(QString::fromUtf8("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(10, 50, 491, 23));
        horizontalLayout_8 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        label_14 = new QLabel(layoutWidget5);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        horizontalLayout_8->addWidget(label_14);

        sendDataEdit = new QLineEdit(layoutWidget5);
        sendDataEdit->setObjectName(QString::fromUtf8("sendDataEdit"));

        horizontalLayout_8->addWidget(sendDataEdit);

        layoutWidget6 = new QWidget(groupBox_2);
        layoutWidget6->setObjectName(QString::fromUtf8("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(480, 80, 192, 30));
        horizontalLayout_9 = new QHBoxLayout(layoutWidget6);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        label_15 = new QLabel(layoutWidget6);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        horizontalLayout_9->addWidget(label_15);

        sendPathCombo = new QComboBox(layoutWidget6);
        sendPathCombo->addItem(QString());
        sendPathCombo->addItem(QString());
        sendPathCombo->setObjectName(QString::fromUtf8("sendPathCombo"));

        horizontalLayout_9->addWidget(sendPathCombo);

        sendBtn = new QPushButton(layoutWidget6);
        sendBtn->setObjectName(QString::fromUtf8("sendBtn"));
        sendBtn->setEnabled(false);

        horizontalLayout_9->addWidget(sendBtn);

        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(0, 430, 991, 371));
        cleanListBtn = new QPushButton(groupBox_3);
        cleanListBtn->setObjectName(QString::fromUtf8("cleanListBtn"));
        cleanListBtn->setGeometry(QRect(880, 60, 93, 28));
        tableWidget = new QTableWidget(groupBox_3);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(10, 20, 861, 341));
        checkBox_4 = new QCheckBox(groupBox_3);
        checkBox_4->setObjectName(QString::fromUtf8("checkBox_4"));
        checkBox_4->setEnabled(true);
        checkBox_4->setGeometry(QRect(880, 30, 91, 19));
        checkBox_4->setChecked(true);
        layoutWidget7 = new QWidget(centralWidget);
        layoutWidget7->setObjectName(QString::fromUtf8("layoutWidget7"));
        layoutWidget7->setGeometry(QRect(10, 30, 441, 23));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget7);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget7);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_5->addWidget(label);

        deviceTypeCombo = new QComboBox(layoutWidget7);
        deviceTypeCombo->addItem(QString());
        deviceTypeCombo->addItem(QString());
        deviceTypeCombo->addItem(QString());
        deviceTypeCombo->setObjectName(QString::fromUtf8("deviceTypeCombo"));

        horizontalLayout_5->addWidget(deviceTypeCombo);

        label_2 = new QLabel(layoutWidget7);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_5->addWidget(label_2);

        deviceIndexCombo = new QComboBox(layoutWidget7);
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->addItem(QString());
        deviceIndexCombo->setObjectName(QString::fromUtf8("deviceIndexCombo"));

        horizontalLayout_5->addWidget(deviceIndexCombo);

        layoutWidget8 = new QWidget(centralWidget);
        layoutWidget8->setObjectName(QString::fromUtf8("layoutWidget8"));
        layoutWidget8->setGeometry(QRect(50, 260, 581, 30));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget8);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        openDeviceBtn = new QPushButton(layoutWidget8);
        openDeviceBtn->setObjectName(QString::fromUtf8("openDeviceBtn"));

        horizontalLayout_6->addWidget(openDeviceBtn);

        initCANBtn = new QPushButton(layoutWidget8);
        initCANBtn->setObjectName(QString::fromUtf8("initCANBtn"));
        initCANBtn->setEnabled(false);

        horizontalLayout_6->addWidget(initCANBtn);

        StartCANBtn = new QPushButton(layoutWidget8);
        StartCANBtn->setObjectName(QString::fromUtf8("StartCANBtn"));
        StartCANBtn->setEnabled(false);

        horizontalLayout_6->addWidget(StartCANBtn);

        reSetCANBtn = new QPushButton(layoutWidget8);
        reSetCANBtn->setObjectName(QString::fromUtf8("reSetCANBtn"));
        reSetCANBtn->setEnabled(false);

        horizontalLayout_6->addWidget(reSetCANBtn);

        closeDeviceBtn = new QPushButton(layoutWidget8);
        closeDeviceBtn->setObjectName(QString::fromUtf8("closeDeviceBtn"));
        closeDeviceBtn->setEnabled(false);

        horizontalLayout_6->addWidget(closeDeviceBtn);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "CANFD", nullptr));
        groupBox->setTitle(QApplication::translate("MainWindow", "\345\217\202\346\225\260\351\205\215\347\275\256", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "\345\267\245\344\275\234\346\250\241\345\274\217\357\274\232", nullptr));
        workStatusCombo->setItemText(0, QApplication::translate("MainWindow", "\346\255\243\345\270\270", nullptr));
        workStatusCombo->setItemText(1, QApplication::translate("MainWindow", "\345\217\252\345\220\254", nullptr));

        label_4->setText(QApplication::translate("MainWindow", "CANFD\346\240\207\345\207\206\357\274\232", nullptr));
        canFDStandardCombo->setItemText(0, QApplication::translate("MainWindow", "CANFD ISO", nullptr));
        canFDStandardCombo->setItemText(1, QApplication::translate("MainWindow", "CANFD BOSCH", nullptr));

        resistanceCheckBox->setText(QApplication::translate("MainWindow", "\347\273\210\347\253\257\347\224\265\351\230\273\344\275\277\350\203\275", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "\344\273\262\350\243\201\345\237\237\346\263\242\347\211\271\347\216\207\357\274\232", nullptr));
        ABIT1Combo->setItemText(0, QApplication::translate("MainWindow", "1Mbps", nullptr));
        ABIT1Combo->setItemText(1, QApplication::translate("MainWindow", "800kbps", nullptr));
        ABIT1Combo->setItemText(2, QApplication::translate("MainWindow", "500kbps", nullptr));
        ABIT1Combo->setItemText(3, QApplication::translate("MainWindow", "250kbps", nullptr));
        ABIT1Combo->setItemText(4, QApplication::translate("MainWindow", "125kbps", nullptr));
        ABIT1Combo->setItemText(5, QApplication::translate("MainWindow", "100kbps", nullptr));
        ABIT1Combo->setItemText(6, QApplication::translate("MainWindow", "50kbps", nullptr));

        label_6->setText(QApplication::translate("MainWindow", "\346\225\260\346\215\256\345\237\237\346\263\242\347\211\271\347\216\207\357\274\232", nullptr));
        ABIT2Combo->setItemText(0, QApplication::translate("MainWindow", "5Mbps", nullptr));
        ABIT2Combo->setItemText(1, QApplication::translate("MainWindow", "4Mbps", nullptr));
        ABIT2Combo->setItemText(2, QApplication::translate("MainWindow", "2Mbps", nullptr));
        ABIT2Combo->setItemText(3, QApplication::translate("MainWindow", "1Mbps", nullptr));

        CustomBaudrateCheckBox->setText(QApplication::translate("MainWindow", "\350\207\252\345\256\232\344\271\211\346\263\242\347\211\271\347\216\207", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "\350\207\252\345\256\232\344\271\211\346\263\242\347\211\271\347\216\207\345\200\274\350\257\267\344\275\277\347\224\250ZCANPRO\347\233\256\345\275\225\344\270\213\347\232\204baudcal\347\224\237\346\210\220", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "\346\273\244\346\263\242\346\250\241\345\274\217\357\274\232", nullptr));
        filterModeCombo->setItemText(0, QApplication::translate("MainWindow", "\346\240\207\345\207\206\345\270\247", nullptr));
        filterModeCombo->setItemText(1, QApplication::translate("MainWindow", "\346\211\251\345\261\225\345\270\247", nullptr));
        filterModeCombo->setItemText(2, QApplication::translate("MainWindow", "\347\246\201\350\203\275", nullptr));

        filterModeCombo->setCurrentText(QApplication::translate("MainWindow", "\346\240\207\345\207\206\345\270\247", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "\350\265\267\345\247\213ID(0x):", nullptr));
        StartIDEdit->setText(QApplication::translate("MainWindow", "00000000", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "\347\273\223\346\235\237ID(0x):", nullptr));
        endIDEdit->setText(QApplication::translate("MainWindow", "FFFFFFFF", nullptr));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\345\217\221\351\200\201", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "ID(0x):", nullptr));
        sendIDEdit->setText(QApplication::translate("MainWindow", "00000000", nullptr));
        label_12->setText(QApplication::translate("MainWindow", "\345\270\247\347\261\273\345\236\213\357\274\232", nullptr));
        frameTypeCombo->setItemText(0, QApplication::translate("MainWindow", "\346\240\207\345\207\206\345\270\247", nullptr));
        frameTypeCombo->setItemText(1, QApplication::translate("MainWindow", "\346\211\251\345\261\225\345\270\247", nullptr));

        label_13->setText(QApplication::translate("MainWindow", "\345\215\217\350\256\256\357\274\232", nullptr));
        protocolCombo->setItemText(0, QApplication::translate("MainWindow", "CAN", nullptr));
        protocolCombo->setItemText(1, QApplication::translate("MainWindow", "CANFD", nullptr));

        CANFDaccCheck->setText(QApplication::translate("MainWindow", "CANFD\345\212\240\351\200\237", nullptr));
        label_14->setText(QApplication::translate("MainWindow", "\346\225\260\346\215\256(0x,\344\273\245\347\251\272\346\240\274\351\232\224\345\274\200)\357\274\232", nullptr));
        sendDataEdit->setText(QApplication::translate("MainWindow", "00 11 22 33 44 55 66 77", nullptr));
        label_15->setText(QApplication::translate("MainWindow", "\351\200\232\351\201\223\357\274\232", nullptr));
        sendPathCombo->setItemText(0, QApplication::translate("MainWindow", "0", nullptr));
        sendPathCombo->setItemText(1, QApplication::translate("MainWindow", "1", nullptr));

        sendBtn->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", nullptr));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\346\216\245\346\224\266", nullptr));
        cleanListBtn->setText(QApplication::translate("MainWindow", "\346\270\205\347\251\272", nullptr));
        checkBox_4->setText(QApplication::translate("MainWindow", "\345\256\236\346\227\266\346\230\276\347\244\272", nullptr));
        label->setText(QApplication::translate("MainWindow", "\350\256\276\345\244\207\347\261\273\345\236\213\357\274\232", nullptr));
        deviceTypeCombo->setItemText(0, QApplication::translate("MainWindow", "USBCANFD-200U", nullptr));
        deviceTypeCombo->setItemText(1, QApplication::translate("MainWindow", "USBCANFD-100U", nullptr));
        deviceTypeCombo->setItemText(2, QApplication::translate("MainWindow", "USBCANFD-MNI", nullptr));

        label_2->setText(QApplication::translate("MainWindow", "\350\256\276\345\244\207\347\264\242\345\274\225\357\274\232", nullptr));
        deviceIndexCombo->setItemText(0, QApplication::translate("MainWindow", "0", nullptr));
        deviceIndexCombo->setItemText(1, QApplication::translate("MainWindow", "1", nullptr));
        deviceIndexCombo->setItemText(2, QApplication::translate("MainWindow", "2", nullptr));
        deviceIndexCombo->setItemText(3, QApplication::translate("MainWindow", "3", nullptr));
        deviceIndexCombo->setItemText(4, QApplication::translate("MainWindow", "4", nullptr));
        deviceIndexCombo->setItemText(5, QApplication::translate("MainWindow", "5", nullptr));
        deviceIndexCombo->setItemText(6, QApplication::translate("MainWindow", "6", nullptr));
        deviceIndexCombo->setItemText(7, QApplication::translate("MainWindow", "7", nullptr));
        deviceIndexCombo->setItemText(8, QApplication::translate("MainWindow", "8", nullptr));
        deviceIndexCombo->setItemText(9, QApplication::translate("MainWindow", "9", nullptr));
        deviceIndexCombo->setItemText(10, QApplication::translate("MainWindow", "10", nullptr));
        deviceIndexCombo->setItemText(11, QApplication::translate("MainWindow", "11", nullptr));
        deviceIndexCombo->setItemText(12, QApplication::translate("MainWindow", "12", nullptr));
        deviceIndexCombo->setItemText(13, QApplication::translate("MainWindow", "13", nullptr));
        deviceIndexCombo->setItemText(14, QApplication::translate("MainWindow", "14", nullptr));
        deviceIndexCombo->setItemText(15, QApplication::translate("MainWindow", "15", nullptr));
        deviceIndexCombo->setItemText(16, QApplication::translate("MainWindow", "16", nullptr));
        deviceIndexCombo->setItemText(17, QApplication::translate("MainWindow", "17", nullptr));
        deviceIndexCombo->setItemText(18, QApplication::translate("MainWindow", "18", nullptr));
        deviceIndexCombo->setItemText(19, QApplication::translate("MainWindow", "19", nullptr));
        deviceIndexCombo->setItemText(20, QApplication::translate("MainWindow", "20", nullptr));
        deviceIndexCombo->setItemText(21, QApplication::translate("MainWindow", "21", nullptr));
        deviceIndexCombo->setItemText(22, QApplication::translate("MainWindow", "22", nullptr));
        deviceIndexCombo->setItemText(23, QApplication::translate("MainWindow", "23", nullptr));
        deviceIndexCombo->setItemText(24, QApplication::translate("MainWindow", "24", nullptr));
        deviceIndexCombo->setItemText(25, QApplication::translate("MainWindow", "25", nullptr));
        deviceIndexCombo->setItemText(26, QApplication::translate("MainWindow", "26", nullptr));
        deviceIndexCombo->setItemText(27, QApplication::translate("MainWindow", "27", nullptr));
        deviceIndexCombo->setItemText(28, QApplication::translate("MainWindow", "28", nullptr));
        deviceIndexCombo->setItemText(29, QApplication::translate("MainWindow", "29", nullptr));
        deviceIndexCombo->setItemText(30, QApplication::translate("MainWindow", "30", nullptr));
        deviceIndexCombo->setItemText(31, QApplication::translate("MainWindow", "31", nullptr));

        openDeviceBtn->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\350\256\276\345\244\207", nullptr));
        initCANBtn->setText(QApplication::translate("MainWindow", "\345\210\235\345\247\213\345\214\226CAN", nullptr));
        StartCANBtn->setText(QApplication::translate("MainWindow", "\345\220\257\345\212\250CAN", nullptr));
        reSetCANBtn->setText(QApplication::translate("MainWindow", "\345\244\215\344\275\215", nullptr));
        closeDeviceBtn->setText(QApplication::translate("MainWindow", "\345\205\263\351\227\255\350\256\276\345\244\207", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
